CONTRIBUTIONS

TODO: write a brief summary of how each team member contributed to
the project.

REPORT

TODO: add your report according to the instructions in the
"Experiments and analysis" section of the assignment description.
