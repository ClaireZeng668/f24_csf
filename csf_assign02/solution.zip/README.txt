Prasi Thapa
Implemented:
imgproc_tile
imgproc_grayscale
unit testing

Claire Zeng
Implemented:
imgproc_mirror_h
imgproc_mirror_v
imgproc_composite
unit testing