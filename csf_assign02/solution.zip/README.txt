Prasi Thapa
Implemented:
imgproc_tile and helper functions

Claire Zeng
Implemented:
imgproc_composite
imgproc_tile and helper functions
