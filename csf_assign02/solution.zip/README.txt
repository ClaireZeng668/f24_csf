Prasi Thapa
Implemented:
imgproc_mirror_v
imgproc_mirror_h
unit testing

Claire Zeng
Implemented:
imgproc_mirror_h
imgproc_grayscale
make_pixel and associated helper functions