Prasi Thapa
Implemented:
asm_imgproc mirror_v
asm_imgproc mirror_h
unit testing

Claire Zeng
Implemented:
asm_imgproc mirror_h
asm_imgproc grayscale
make_pixel and associated helper functions

Commented out tests are for functions not implemented in MS2. They will be implemented in MS3 and will be uncommented then.