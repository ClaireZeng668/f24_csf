Prasi Thapa
Implemented:
cache.cpp
main.cpp
Makefile

Claire Zeng
Implemented:
cache.cpp
main.cpp
Makefile