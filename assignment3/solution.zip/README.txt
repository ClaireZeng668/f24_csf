Prasi Thapa
Implemented:
cache.cpp
main.cpp
Makefile

Claire Zeng
Implemented:
main.cpp
Makefile